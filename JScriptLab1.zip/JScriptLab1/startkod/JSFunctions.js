"use strict";

/**
 * Globalt objekt som innehåller de attribut som ni skall använda.
 * Initieras genom anrop till funktionern initGlobalObject().
 */
let oGameData = {};

/**
 * Initerar det globala objektet med de attribut som ni skall använda er av.
 * Funktionen tar inte emot några värden.
 * Funktionen returnerar inte något värde.
 */
oGameData.initGlobalObject = function() 
{

    //Datastruktur för vilka platser som är lediga respektive har brickor
    //oGameData.gameField = Array('', '', '', '', '', '', '', '', '');
    // Rutorna! ('0', '1', '2', '3', '4', '5', '6', '7', '8');
    /* Testdata för att testa rättningslösning */
    //oGameData.gameField = Array('X', 'O', 'X', '', 'X', '', 'O', 'O', 'O');
    //oGameData.gameField = Array('X', 'X', 'O', 'O', 'X', 'X', 'O', 'O', 'O');
    //oGameData.gameField = Array('O', '', '', 'O', '', '', 'O', '', '');
    //oGameData.gameField = Array('O', '', '', '', 'O', '', '', '', 'O');
    //oGameData.gameField = Array('', '', 'X', '', 'X', '', 'X', '', '');
    //oGameData.gameField = Array('X', 'O', 'X', 'O', 'X', 'O', 'O', 'X', 'O');// == return 0;
   //oGameData.gameField = Array('O', 'X', 'X', 'O', 'X', 'O', 'O', 'O', 'X'); //return 3;
   //oGameData.gameField = Array('X', 'O', 'X', 'O', 'X', 'X', 'O', 'O', 'O'); //Ragequit ( Har testat och lägga ut sista spelpjäsen där X vinne Diagonalt får 1 läger vi O eller på plats 8 returnerar de 2om inget retunerar de3)


    //Indikerar tecknet som skall användas för spelare ett.
    oGameData.playerOne = "X";

    //Indikerar tecknet som skall användas för spelare två.
    oGameData.playerTwo = "O";

    //Kan anta värdet X eller O och indikerar vilken spelare som för tillfället skall lägga sin "bricka".
    oGameData.currentPlayer = "";

    //Nickname för spelare ett som tilldelas från ett formulärelement,
    oGameData.nickNamePlayerOne = "";

    //Nickname för spelare två som tilldelas från ett formulärelement.
    oGameData.nickNamePlayerTwo = "";

    //Färg för spelare ett som tilldelas från ett formulärelement.
    oGameData.colorPlayerOne = "";

    //Färg för spelare två som tilldelas från ett formulärelement.
    oGameData.colorPlayerTwo = "";

    //"Flagga" som indikerar om användaren klickat för checkboken.
    oGameData.timerEnabled = false;

    //Timerid om användaren har klickat för checkboxen. 
    oGameData.timerId = null;

}
// Horizontal
oGameData.checkHorizontal  = function()  
{ 
    /* Kollar om X är vinnare  Här är alla Varianter X kan vinna på i Horizontalt sätt */
    if(oGameData.gameField[0] == ['X'] && oGameData.gameField[1] == ['X'] && oGameData.gameField[2] == ['X'])
    {
        return 1;
    }
    if(oGameData.gameField[3] == ['X'] && oGameData.gameField[4] == ['X'] && oGameData.gameField[5] == ['X'])
    {
        return 1;
    }
    if(oGameData.gameField[6] == ['X'] && oGameData.gameField[7] == ['X'] && oGameData.gameField[8] == ['X'])
    {
        return 1;
    }

    /* Kollar om O är vinnare  Här är alla Varianter 0 kan vinna på i Horizontalt sätt*/
    if(oGameData.gameField[0] == ['O'] && oGameData.gameField[1] == ['O'] && oGameData.gameField[2] == ['O'])
    {
        return 2;
    }
    if(oGameData.gameField[3] == ['O'] && oGameData.gameField[4] == ['O'] && oGameData.gameField[5] == ['O'])
    {
        return 2;
    }
    if(oGameData.gameField[6] == ['O'] && oGameData.gameField[7] == ['O'] && oGameData.gameField[8] == ['O'])
    {
        return 2;
    }

}



// Vertical
oGameData.checkVertical = function ()
{
    /* Kollar om X är vinnare Här är alla Varianter X kan vinna på i Vertical sätt */
    if(oGameData.gameField[0] == ['X'] && oGameData.gameField[3] == ['X'] && oGameData.gameField[6] == ['X'])
    {
        return 1;
    }
    if(oGameData.gameField[1] == ['X'] && oGameData.gameField[4] == ['X'] && oGameData.gameField[7] == ['X'])
    {
        return 1;
    }
    if(oGameData.gameField[2] == ['X'] && oGameData.gameField[5] == ['X'] && oGameData.gameField[8] == ['X'])
    {
        return 1;
    }

    /* Kollar om O är vinnare Här är alla Varianter O kan vinna på i Vertical sätt */
    if(oGameData.gameField[0] == ['O'] && oGameData.gameField[3] == ['O'] && oGameData.gameField[6] == ['O'])
    {
        return 2;
    }
    if(oGameData.gameField[1] == ['O'] && oGameData.gameField[4] == ['O'] && oGameData.gameField[7] == ['O'])
    {
        return 2;
    }
    if(oGameData.gameField[2] == ['O'] && oGameData.gameField[5] == ['O'] && oGameData.gameField[8] == ['O'])
    {
        return 2;
    }
}
// Diagonal: Left to right
oGameData.checkDiagonalLeftToRight = function()
{
    /* Kollar om X är vinnare */
    if(oGameData.gameField[0] == ['X'] && oGameData.gameField[4] == ['X'] && oGameData.gameField[8] == ['X'])
    {
        return 1;
    }
    /* Kollar om O är vinnare */
    if(oGameData.gameField[0] == ['O'] && oGameData.gameField[4] == ['O'] && oGameData.gameField[8] == ['O'])
    {
        return 2;
    } 
}
// Diagonal: Right to left
oGameData.checkDiagonalRightToLeft = function()
{
    /* Kollar om X är vinnare */
    if(oGameData.gameField[2] == ['X'] && oGameData.gameField[4] == ['X'] && oGameData.gameField[6] == ['X'])
    {
        return 1;
    }
        
        /* Kollar om O är vinnare */
    if(oGameData.gameField[2] == ['O'] && oGameData.gameField[4] == ['O'] && oGameData.gameField[6] == ['O'])
    {
        return 2;
    }
}



oGameData.checkForDraw = function()
{
/* Går igenom gameField och kollar efter tomma positioner 
    och returnerar 0 om den hittar en tomm position. Och ingen vinnare är given*/
    for (let i = 0; i < 8; i++)
        {
            if(oGameData.gameField[i] == '')
            {
                return 0;
            }
        }
    return 3;
/*     Verkar som att vi inte behöver denna koden, fungerar felfritt utan den. 

if( oGameData.checkVertical() == 1 || oGameData.checkVertical() == 2 ||
    oGameData.checkHorizontal() == 1 || oGameData.checkHorizontal() == 2 ||
    oGameData.checkDiagonalLeftToRight() == 1 || oGameData.checkDiagonalLeftToRight() == 2 ||
    oGameData.checkDiagonalRightToLeft() == 1 || oGameData.checkDiagonalRightToLeft() == 2)
{
    return null;
}

else 
{
    return 3;
}*/

}


oGameData.checkForGameOver = function() 
{
    /* Om den retunerar 1 eller 2 så ska den checkForGameOver retunera denna funktion. */
    if(oGameData.checkVertical() == 1 || oGameData.checkVertical() == 2)
    {
        return oGameData.checkVertical(); 
    }

    /* Om den retunerar 1 eller 2 så ska den checkForGameOver retunera denna funktion. */
    if(oGameData.checkHorizontal() == 1 || oGameData.checkHorizontal() == 2)
    {
        return oGameData.checkHorizontal(); 
    }

    /* Om den retunerar 3 så ska den checkForGameOver retunera denna funktion.  Peter sa att vi bör flytta ner den. */
   /* if(oGameData.checkForDraw() == 3 || oGameData.checkForDraw() == 0)
    {
        return oGameData.checkForDraw();
    }*/

    /* Om den retunerar 1 eller 2 så ska den checkForGameOver retunera denna funktion. */
    if(oGameData.checkDiagonalLeftToRight() == 1 || oGameData.checkDiagonalLeftToRight() == 2)
    {
        return oGameData.checkDiagonalLeftToRight(); 
    }

    /* Om den retunerar 1 eller 2 så ska den checkForGameOver retunera denna funktion. */
    if(oGameData.checkDiagonalRightToLeft() == 1 || oGameData.checkDiagonalRightToLeft() == 2)
    {
        return oGameData.checkDiagonalRightToLeft(); 
    }

      /* Om den retunerar 3 så ska den checkForGameOver retunera denna funktion. */
    if(oGameData.checkForDraw() == 3 || oGameData.checkForDraw() == 0)
      {
          return oGameData.checkForDraw();
      }

} 
