// check for gameover 

if (Array[0] == Array[1] && Array[0] == Array[2]) {
    return Array[0];
} else if (Array[3] == Array[4] && Array[3] == Array[5]) {
    return Array[3];
} else if (Array[6] == Array[7] && Array[6] == Array[8]) {
    return Array[6];
} else if (Array[0] == Array[3] && Array[0] == Array[6]) {
    return Array[0];
} else if (Array[1] == Array[4] && Array[1] == Array[7]) {
    return Array[1];
} else if (Array[2] == Array[5] && Array[2] == Array[8]) {
    return winner = Array[2];
} else if (Array[0] == Array[4] && Array[0] == Array[8]) {
    return Array[0];
}else if (Array[2] == Array[4] && Array[2] == Array[6]) {
    return Array[2];
}




/* KOllar om X är vinnare */
if(Array[0] == ['X'] && Array[1] == ['X'] && Array[2] == ['X'])
    {
        return '1';
    }
    if(Array[3] == ['X'] && Array[4] == ['X'] && Array[5] == ['X'])
    {
        return '1';
    }
    if(Array[6] == ['X'] && Array[7] == ['X'] && Array[8] == ['X'])
    {
        return '1';
    }
 
    /* Kollar om 0 är vinnare */
    if(Array[0] == ['0'] && Array[1] == ['0'] && Array[2] == ['0'])
    {
        return '1';
    }
    if(Array[3] == ['0'] && Array[4] == ['0'] && Array[5] == ['0'])
    {
        return '1';
    }
    if(Array[6] == ['0'] && Array[7] == ['0'] && Array[8] == ['0'])
    {
        return '1';
    }