


/*
function draw () {

    let w = width / 3; 
    let h = height / 3;
     
    for ( let i= 0; i < 3; i++) {
    for ( let j = 0; j < 3; j++) {
    let x = w * i; 
    let y = h * j;
    let spot = board[I][j];
    textSize(32); 
    text(spot, x, y); 
    } 
}
}




winner = null;

// Horizontal
function checkHorizontal()
{
    for (let i = 0; i < 3; i++)
    {
        if(Array[i][0] == Array[i][1] == Array[i][2])
        {
            winner = Array[i][0];
        }
    }
}

// Vertical
function checkVertical()
{
    for (let i = 0; i < 3; i++)
    {
        if(Array[0][i] == Array[0][i] == Array[0][i])
        {
            winner = Array[0][i];
        }
    }
}
// Diagonal: Left to right
function checkDiagonalRightToLeft()
{
    if(Array[0][0] == Array[1][1] == Array[2][2])
    {
        winner = Array[0][0];
    }
}

// Diagonal: Right to left
function checkDiagonalRightToLeft()
{
    if(Array[2][0] == Array[1][1] == Array[0][2])
    {
        winner = Array[0][0];
    }
}



*/

/*



function checkwinner() {
    let winner = null;
   
   
   function checkHorizontal()
   {
       for (let i = 0; i < 3; i++)
       {
           if(Array[i][0] == Array[i][1] == Array[i][2])
           {
               winner = Array[i][0];
           }
       }
   
   
   
   }
   function checkForHorizontal(gameField); 
   

   */
  



   /*

    
// Horizontal
 oGameData.checkHorizontal = function(){  
 // skit i forloopar , & istället för lika 
 // en viktor inte array  0 till 8 
 // array [1] = 0 etc.. 
/*{ 
    for (let i = 0; i < 3; i++)
    {
        if(Array[i][0] == Array[i][1] == Array[i][2])
        {
            winner = Array[i][0];
        }
    }
}



//if {
    checkHorizontal=[0, 1, 2]||checkHorizontal=[3, 4, 5]||checkHorizontal=[6, 7, 8];
    print("Winner");
    }
 }


// Vertical
function checkVertical()
{ 
    if {
        checkVertical=[0, 3, 6]||checkVertical=[1, 4, 7]||checkVertical=[2, 5, 8];
        print("Winner");
    }
}
 
    for (let i = 0; i < 3; i++)
    {
        if(Array[0][i] == Array[0][i] == Array[0][i])
        {
            winner = Array[0][i];
        }
    }
}

// Diagonal: Left to right
function checkDiagonalLeftToRight(){
/*{
    if(Array[0][0] == Array[1][1] == Array[2][2])
    {
        winner = Array[0][0];
    }
}
if {
        checkDiagonalLeftToRight=[0, 4, 8];
        print("Winner");
    }
 }

// Diagonal: Right to left
function checkDiagonalRightToLeft()
{

    if {
        checkDiagonalRightToLeft=[2, 4, 6]
        print("Winner");
    }
}
   /* if(Array[2][0] == Array[1][1] == Array[0][2])
    {
        winner = Array[0][0];
    }
}


}


/*
 * Kontrollerar för tre i rad.
 * Returnerar 0 om det inte är någon vinnare, 
 * returnerar 1 om spelaren med ett kryss (X) är vinnare,
 * returnerar 2 om spelaren med en cirkel (O) är vinnare eller
 * returnerar 3 om det är oavgjort.
 * Funktionen tar inte emot några värden.
 * checkHorizontal(), kolla med if-satser om fälten radvis är lika  checkVertical()
 * checkDiagonalLeftToRight()
 * checkDiagonalRightToLeft()
 * 


oGameData.checkForGameOver = function () 
{
        //oGameData.checkHorizontal();
        oGameData.checkVertical();
        oGameData.checkDiagonalRightToLeft();
        oGameData.checkDiagonalLeftToRight();
        oGameData.console.log(winner);



        /* Skall returnera detta */
       /* 0: om ingen vinnare finns
        1: om spelare ett (X) har vunnit
        2: om spelare två (O) har vunnit
        3: om spelet blivit oavgjort ,d.vs.inga tomma fält finns kvar på spelplanen. 
}

    

    oGameData.draw = function (draw) {

        let w = width / 3; 
        let h = height / 3;
         
        for ( let i= 0; i < 3; i++) {
        for ( let j = 0; j < 3; j++) {
        let x = w * i; 
        let y = h * j;
        let spot = board[i][j];
        text(spot, x, y); 
        } 
    }
    }
 
    


   // oGameData.checkForHorizontal = function ();

   // checkVertical()
   */